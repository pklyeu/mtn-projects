package com.test;

class Test {

  public static void main(String[] args) {
    System.out.println("Hellow MTN");
  }

}