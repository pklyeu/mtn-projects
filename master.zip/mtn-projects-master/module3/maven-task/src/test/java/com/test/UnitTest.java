package com.test;

import org.junit.Test;

public class UnitTest {
   
   @Test
   public void test(){
     Project.test();
   }
}